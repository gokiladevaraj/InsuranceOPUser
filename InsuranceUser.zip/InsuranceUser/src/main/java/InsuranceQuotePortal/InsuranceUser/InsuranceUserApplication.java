package InsuranceQuotePortal.InsuranceUser;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InsuranceUserApplication {

	public static void main(String[] args) {
		SpringApplication.run(InsuranceUserApplication.class, args);
	}

}
