package InsuranceQuotePortal.InsuranceUser;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InsuranceUserApplicationTests {

	@Test
	void contextLoads() {
	}

}
